from app.extensions import db
from app import create_app
from sqlalchemy import text   # ✅ IMPORTANT

app = create_app()

with app.app_context():

    # 🔥 Disable foreign key checks
    db.session.execute(text("SET FOREIGN_KEY_CHECKS=0;"))

    db.drop_all()

    # 🔥 Enable again
    db.session.execute(text("SET FOREIGN_KEY_CHECKS=1;"))

    db.create_all()

    print("Database reset successful!")