# 🛠️ Local Service Marketplace

A web-based platform that connects local service providers with customers, enabling service discovery, booking, and reviews.

## 🚀 Features

- User Authentication (Login/Register)
- Service Listings
- Booking System
- Review & Rating System
- Secure Password Hashing
- Role-Based Access Control

## 🏗️ Tech Stack

- Backend: Flask (Python)
- Frontend: HTML, CSS, Bootstrap
- Database: MySQL
- ORM: SQLAlchemy

## ⚙️ Setup Instructions

1. Clone repository: