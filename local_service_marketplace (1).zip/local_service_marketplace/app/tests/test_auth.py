from app.models.user import User
from app.extensions import db


def test_register(client, app):
    response = client.post("/auth/register", data={
        "email": "test@example.com",
        "password": "123456",
        "role": "customer"
    }, follow_redirects=True)

    assert response.status_code == 200

    with app.app_context():
        user = User.query.filter_by(email="test@example.com").first()
        assert user is not None


def test_login(client, app):
    with app.app_context():
        user = User(email="login@test.com", password="123456", role="customer")
        db.session.add(user)
        db.session.commit()

    response = client.post("/auth/login", data={
        "email": "login@test.com",
        "password": "123456"
    }, follow_redirects=True)

    assert response.status_code == 200