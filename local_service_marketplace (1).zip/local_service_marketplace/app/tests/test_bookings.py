from app.models.user import User
from app.extensions import db


def login(client):
    return client.post("/auth/login", data={
        "email": "service@test.com",
        "password": "123456"
    }, follow_redirects=True)


def test_create_service(client, app):
    with app.app_context():
        user = User(email="service@test.com", password="123456", role="provider")
        db.session.add(user)
        db.session.commit()

    login(client)

    response = client.post("/services/create", data={
        "title": "Plumbing Service",
        "description": "Fix pipes",
        "price": "500",
        "category": "Home"
    }, follow_redirects=True)

    assert response.status_code == 200