from app.models.user import User
from app.models.service import Service
from app.extensions import db


def login(client):
    return client.post("/auth/login", data={
        "email": "bookings@test.com",
        "password": "123456"
    }, follow_redirects=True)


def test_create_booking(client, app):
    with app.app_context():
        user = User(email="bookings@test.com", password="123456", role="customer")
        db.session.add(user)
        db.session.commit()

        service = Service(
            title="Cleaning",
            description="House cleaning",
            price=300,
            category="Home",
            provider_id=user.id
        )
        db.session.add(service)
        db.session.commit()

    login(client)

    response = client.get(f"/bookings/create/{service.id}", follow_redirects=True)

    assert response.status_code == 200