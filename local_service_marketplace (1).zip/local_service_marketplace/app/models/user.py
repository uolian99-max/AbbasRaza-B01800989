from app.extensions import db
from flask_login import UserMixin
from datetime import datetime


class User(db.Model, UserMixin):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)

    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)

    phone = db.Column(db.String(20))
    address = db.Column(db.String(255))

    role = db.Column(db.String(20), nullable=False)  # customer / provider / admin

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    # ✅ RELATIONSHIPS (FIXED)

    # Services created by provider
    services = db.relationship(
        "Service",
        backref="provider",
        lazy=True
    )

    # Bookings made by this user (customer)
    bookings = db.relationship(
        "Booking",
        back_populates="customer",
        lazy=True
    )

    # Reviews by user
    reviews = db.relationship(
        "Review",
        backref="user",
        lazy=True
    )

    def __repr__(self):
        return f"<User {self.email} | Role: {self.role}>"