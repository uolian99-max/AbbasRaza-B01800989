from app.extensions import db
from datetime import datetime


class Booking(db.Model):
    __tablename__ = "bookings"

    id = db.Column(db.Integer, primary_key=True)

    customer_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=False
    )

    service_id = db.Column(
        db.Integer,
        db.ForeignKey("services.id"),
        nullable=False
    )

    booking_date = db.Column(db.DateTime, default=datetime.utcnow)
    scheduled_date = db.Column(db.DateTime)

    status = db.Column(db.String(50), default="pending")
    # pending / confirmed / completed / cancelled

    completion_date = db.Column(db.DateTime)

    # ✅ FIXED RELATIONSHIPS (CONSISTENT)
    customer = db.relationship(
        "User",
        back_populates="bookings",
        lazy=True
    )

    service = db.relationship(
        "Service",
        back_populates="bookings",
        lazy=True
    )

    # Optional relationships
    transaction = db.relationship(
        "Transaction",
        backref="booking",
        uselist=False,
        lazy=True
    )

    review = db.relationship(
        "Review",
        backref="booking",
        uselist=False,
        lazy=True
    )

    def __repr__(self):
        return f"<Booking {self.id} | Status: {self.status}>"