from app.extensions import db
from datetime import datetime


class AdminLog(db.Model):
    __tablename__ = "admin_logs"

    id = db.Column(db.Integer, primary_key=True)

    admin_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    action = db.Column(db.String(255), nullable=False)
    target_type = db.Column(db.String(50))  # user / service / bookings
    target_id = db.Column(db.Integer)

    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    remarks = db.Column(db.Text)

    def __repr__(self):
        return f"<AdminLog {self.action}>"