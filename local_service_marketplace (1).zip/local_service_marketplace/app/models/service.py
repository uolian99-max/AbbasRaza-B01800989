from app.extensions import db
from datetime import datetime


class Service(db.Model):
    __tablename__ = "services"

    id = db.Column(db.Integer, primary_key=True)

    provider_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=False
    )

    category = db.Column(db.String(100), nullable=False)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)

    price = db.Column(db.Float, nullable=False)
    estimated_time = db.Column(db.String(50))
    location = db.Column(db.String(100))

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # ✅ RELATIONSHIPS (CONSISTENT)

    # Bookings for this service
    bookings = db.relationship(
        "Booking",
        back_populates="service",
        lazy=True,
        cascade="all, delete-orphan"
    )

    # Reviews for this service
    reviews = db.relationship(
        "Review",
        backref="service",
        lazy=True,
        cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<Service {self.title} | €{self.price}>"