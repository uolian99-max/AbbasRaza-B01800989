// Simple alert fade out
setTimeout(() => {
    let alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        alert.style.display = 'none';
    });
}, 3000);


// Example: confirmation before booking
function confirmBooking() {
    return confirm("Are you sure you want to book this service?");
}