from flask import Flask
from .config import Config
from .extensions import db, login_manager, bcrypt


def create_app():
    app = Flask(__name__)

    # Load configuration
    app.config.from_object(Config)

    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    bcrypt.init_app(app)

    # Login manager settings
    login_manager.login_view = "auth.login"
    login_manager.login_message_category = "info"

    # User Loader
    from app.models.user import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # =============================
    # REGISTER BLUEPRINTS
    # =============================
    from .routes.auth_routes import auth_bp
    from .routes.user_routes import user_bp
    from .routes.service_routes import service_bp
    from .routes.booking_routes import booking_bp
    from .routes.review_routes import review_bp
    from .routes.admin_routes import admin_bp
    from .routes.chatbot_routes import chatbot_bp
    from .routes.main_routes import main_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(service_bp)
    app.register_blueprint(booking_bp)
    app.register_blueprint(review_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(chatbot_bp)
    app.register_blueprint(main_bp)

    return app