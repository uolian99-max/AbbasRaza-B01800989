from flask import flash

def flash_message(message, category="info"):
    flash(message, category)

def format_currency(amount):
    return f"€ {amount:.2f}"