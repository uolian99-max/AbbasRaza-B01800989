import re


def is_valid_email(email):
    pattern = r"^[\w\.-]+@[\w\.-]+\.\w+$"
    return re.match(pattern, email)


def is_strong_password(password):
    return len(password) >= 6


def validate_service_data(title, price):
    if not title or not price:
        return False, "Title and price are required"
    return True, ""