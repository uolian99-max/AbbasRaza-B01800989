import os
from dotenv import load_dotenv

load_dotenv()  # Load .env file


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "fallback_secret_key")

    # MySQL Database URI
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DB_URI",
        "mysql+pymysql://root:password@localhost/marketplace_db"
    )

    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Security settings
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SECURE = False  # Set True in production (HTTPS)

    # Optional: Upload folder (future use)
    UPLOAD_FOLDER = os.path.join(os.getcwd(), "app/static/images")

    # Optional: Pagination
    ITEMS_PER_PAGE = 10