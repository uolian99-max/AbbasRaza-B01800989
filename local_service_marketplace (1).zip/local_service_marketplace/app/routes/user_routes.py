from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app import db

user_bp = Blueprint("user", __name__)


@user_bp.route("/dashboard")
@login_required
def dashboard():
    return render_template("user/dashboard.html", user=current_user)


@user_bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():

    if request.method == "POST":
        current_user.email = request.form.get("email")
        current_user.role = request.form.get("role")

        db.session.commit()
        flash("Profile updated successfully!", "success")

        return redirect(url_for("user.profile"))

    return render_template("user/profile.html", user=current_user)