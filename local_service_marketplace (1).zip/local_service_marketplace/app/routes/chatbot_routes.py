from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from app.models.service import Service
from app.models.booking import Booking
import requests
import os

chatbot_bp = Blueprint("chatbot", __name__, url_prefix="/chatbot")

# 🔐 API CONFIG
SAMBANOVA_API_KEY = os.getenv("SAMBANOVA_API_KEY")
SAMBANOVA_URL = "https://api.sambanova.ai/v1/chat/completions"


# ✅ FETCH LIVE DATA FROM DATABASE
def get_service_context():
    services = Service.query.all()

    if not services:
        return "Currently no services are listed on ServiceHub."

    context = "Here are the services currently available on ServiceHub:\n\n"

    for s in services:
        provider = s.provider
        context += f"- Service: {s.title}\n"
        context += f"  Category: {s.category}\n"
        context += f"  Description: {s.description}\n"
        context += f"  Price: £{s.price}\n"
        if s.estimated_time:
            context += f"  Estimated Time: {s.estimated_time}\n"
        if s.location:
            context += f"  Location: {s.location}\n"
        if provider:
            context += f"  Provider Email: {provider.email}\n"
            context += f"  Provider Phone: {provider.phone if provider.phone else 'Not available'}\n"
        context += "\n"

    return context


# ✅ LLM CALL WITH LIVE DATABASE CONTEXT
def call_allam_llm(user_message):
    try:
        if not SAMBANOVA_API_KEY:
            print("❌ API KEY NOT FOUND")
            return "AI service not configured properly."

        # 🔥 Pull real data from database
        service_data = get_service_context()

        headers = {
            "Authorization": f"Bearer {SAMBANOVA_API_KEY}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": "Meta-Llama-3.3-70B-Instruct",
            "messages": [
                {
                    "role": "system",
                    "content": f"""You are the AI assistant for ServiceHub - a local service marketplace website.

You ONLY answer questions related to this platform and its services.

Here is the LIVE data from our database. Use this to answer user questions accurately:

{service_data}

When a user asks about a service (e.g. plumber, cleaner, tutor, electrician, TV mechanic):
- Check the data above and tell them the exact details.
- If the service exists, respond in this exact format:

✅ Yes, we have [service name] available!

🔧 Service: [title]
📂 Category: [category]
📝 Description: [description]
💷 Price: £[price]
⏱️ Estimated Time: [time if available]
📍 Location: [location if available]
📧 Provider: [email]
📞 Phone: [phone or "Not available"]

👉 To book, go to the service page → View Details → Book Now!

- If multiple services match, list all of them in the same format.
- If the service does NOT exist, say:
❌ Sorry, we don't have that service listed right now. Please check back later or browse our services page.

You can also help with:
- How to book: "Go to the service page → View Details → Book Now"
- Booking status: "Go to My Bookings from your dashboard"
- Payment: "After booking, you'll be redirected to payment. We accept credit and debit cards"
- Cancel booking: "Go to My Bookings → Cancel Request on any pending booking"
- Leave a review: "After service is completed, you can leave a rating and review"
- Edit profile: "Go to My Profile → Click Edit"
- Account help: "Register as Customer or Service Provider from the registration page"

If a user asks anything unrelated to ServiceHub (e.g. general knowledge, news, coding, politics, weather, sports), politely decline and say:
🚫 I can only help with questions related to ServiceHub. Please ask me about our services, bookings, payments, or your account.

Always use emojis and the structured format above. Keep responses clean and organised."""
                },
                {
                    "role": "user",
                    "content": user_message
                }
            ],
            "temperature": 0.7,
            "max_tokens": 300
        }

        response = requests.post(
            SAMBANOVA_URL,
            headers=headers,
            json=payload,
            timeout=10
        )

        print("🔹 STATUS:", response.status_code)
        print("🔹 RESPONSE:", response.text)

        if response.status_code == 200:
            data = response.json()
            return data["choices"][0]["message"]["content"]

        elif response.status_code == 401:
            return "Authentication failed. Please verify your API key."

        elif response.status_code == 429:
            return "Rate limit reached. Please try again later."

        else:
            return f"AI service error ({response.status_code})"

    except requests.exceptions.Timeout:
        return "Request timed out. Please try again."

    except Exception as e:
        print("❌ ERROR:", str(e))
        return "AI service error occurred."


# 📄 CHAT PAGE
@chatbot_bp.route("/")
@login_required
def chat():
    if current_user.role != "customer":
        return "Unauthorized", 403
    return render_template("chatbot/chat.html")


# 💬 MAIN CHAT LOGIC
@chatbot_bp.route("/ask", methods=["POST"])
@login_required
def ask():
    data = request.get_json()
    user_message = data.get("message")

    if not user_message:
        return jsonify({
            "model": "System",
            "response": "Please enter a message."
        })

    # 🔥 DIRECT LLM CALL WITH DATABASE CONTEXT
    llm_response = call_allam_llm(user_message)

    return jsonify({
        "model": "Meta-Llama-3.3-70B-Instruct",
        "response": llm_response
    })