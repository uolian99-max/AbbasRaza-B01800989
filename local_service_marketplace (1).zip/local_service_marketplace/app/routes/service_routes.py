from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app.models.service import Service
from app.extensions import db

service_bp = Blueprint("service", __name__, url_prefix="/services")


@service_bp.route("/")
def list_services():
    services = Service.query.all()
    return render_template("services/list_services.html", services=services)


@service_bp.route("/create", methods=["GET", "POST"])
@login_required
def create_service():
    if request.method == "POST":
        title = request.form.get("title")
        description = request.form.get("description")
        price = request.form.get("price")
        category = request.form.get("category")
        phone = request.form.get("phone")

        service = Service(
            title=title,
            description=description,
            price=price,
            category=category,
            provider_id=current_user.id
        )

        # ✅ Save phone to provider's profile
        if phone:
            current_user.phone = phone

        db.session.add(service)
        db.session.commit()

        return redirect(url_for("service.list_services"))

    return render_template("services/create_service.html")


@service_bp.route("/<int:id>")
def service_detail(id):
    service = Service.query.get_or_404(id)
    return render_template("services/service_detail.html", service=service)


# ✅ EDIT SERVICE
@service_bp.route("/edit/<int:id>", methods=["GET", "POST"])
@login_required
def edit_service(id):
    service = Service.query.get_or_404(id)

    # Only admin or the provider who created it can edit
    if current_user.role != "admin" and current_user.id != service.provider_id:
        return "Unauthorized", 403

    if request.method == "POST":
        service.title = request.form.get("title")
        service.description = request.form.get("description")
        service.price = request.form.get("price")
        service.category = request.form.get("category")

        phone = request.form.get("phone")
        if phone:
            service.provider.phone = phone

        db.session.commit()
        flash("Service updated successfully!", "success")
        return redirect(url_for("service.service_detail", id=service.id))

    return render_template("services/edit_service.html", service=service)


# ✅ DELETE SERVICE
@service_bp.route("/delete/<int:id>")
@login_required
def delete_service(id):
    service = Service.query.get_or_404(id)

    # Only admin or the provider who created it can delete
    if current_user.role != "admin" and current_user.id != service.provider_id:
        return "Unauthorized", 403

    db.session.delete(service)
    db.session.commit()
    flash("Service deleted successfully!", "success")
    return redirect(url_for("service.list_services"))