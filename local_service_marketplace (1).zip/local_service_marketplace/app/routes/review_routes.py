from flask import Blueprint, request, redirect, url_for
from flask_login import login_required, current_user
from app.models.review import Review
from app.extensions import db

review_bp = Blueprint("review", __name__, url_prefix="/reviews")


@review_bp.route("/add/<int:booking_id>", methods=["POST"])
@login_required
def add_review(booking_id):
    rating = request.form.get("rating")
    comment = request.form.get("comment")
    service_id = request.form.get("service_id")

    review = Review(
        booking_id=booking_id,
        user_id=current_user.id,
        service_id=service_id,
        rating=rating,
        comment=comment
    )

    db.session.add(review)
    db.session.commit()

    return redirect(url_for("service.list_services"))