from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.models.booking import Booking
from app.models.service import Service
from app.extensions import db

booking_bp = Blueprint("bookings", __name__, url_prefix="/bookings")


# ✅ LIST BOOKINGS (ADMIN + USER LOGIC)
@booking_bp.route("/")
@login_required
def list_bookings():

    if current_user.role == "admin":
        bookings = Booking.query.order_by(Booking.id.desc()).all()
    else:
        bookings = Booking.query.filter_by(
            customer_id=current_user.id
        ).order_by(Booking.id.desc()).all()

    return render_template("bookings/booking_list.html", bookings=bookings)


# ✅ CREATE BOOKING → REDIRECT TO PAYMENT
@booking_bp.route("/create/<int:service_id>")
@login_required
def create_booking(service_id):
    service = Service.query.get_or_404(service_id)

    booking = Booking(
        customer_id=current_user.id,
        service_id=service.id,
        status="pending"
    )

    db.session.add(booking)
    db.session.commit()

    return redirect(url_for("bookings.payment_page", booking_id=booking.id))


# ✅ PAYMENT PAGE
@booking_bp.route("/payment/<int:booking_id>")
@login_required
def payment_page(booking_id):
    booking = Booking.query.get_or_404(booking_id)

    if booking.customer_id != current_user.id:
        return "Unauthorized", 403

    return render_template("bookings/payment.html", booking=booking)


# ✅ CONFIRM PAYMENT (USER SIDE)
@booking_bp.route("/confirm-payment/<int:booking_id>", methods=["POST"])
@login_required
def confirm_payment(booking_id):
    booking = Booking.query.get_or_404(booking_id)

    if booking.customer_id != current_user.id:
        return "Unauthorized", 403

    # Optional: keep as pending until admin approves
    booking.status = "pending"
    db.session.commit()

    flash("Payment successful! Waiting for admin approval.", "info")
    return redirect(url_for("bookings.list_bookings"))


# ✅ DELETE BOOKING (USER + ADMIN)
@booking_bp.route("/delete/<int:id>")
@login_required
def delete_booking(id):
    booking = Booking.query.get_or_404(id)

    if booking.customer_id != current_user.id and current_user.role != "admin":
        return "Unauthorized", 403

    db.session.delete(booking)
    db.session.commit()

    flash("Booking deleted successfully!", "success")
    return redirect(url_for("bookings.list_bookings"))


# ✅ APPROVE BOOKING (ADMIN ONLY)
@booking_bp.route("/approve/<int:id>")
@login_required
def approve_booking(id):
    if current_user.role != "admin":
        return "Unauthorized", 403

    booking = Booking.query.get_or_404(id)

    # ✅ Only approve if pending
    if booking.status != "pending":
        flash("Only pending bookings can be approved.", "warning")
        return redirect(url_for("bookings.list_bookings"))

    booking.status = "confirmed"
    db.session.commit()

    flash("Booking approved successfully!", "success")
    return redirect(url_for("bookings.list_bookings"))


# ✅ CANCEL BOOKING (ADMIN ONLY)
@booking_bp.route("/cancel/<int:id>")
@login_required
def cancel_booking(id):
    if current_user.role != "admin":
        return "Unauthorized", 403

    booking = Booking.query.get_or_404(id)

    # Optional safety
    if booking.status == "cancelled":
        flash("Booking is already cancelled.", "warning")
        return redirect(url_for("bookings.list_bookings"))

    booking.status = "cancelled"
    db.session.commit()

    flash("Booking cancelled successfully!", "warning")
    return redirect(url_for("bookings.list_bookings"))


# ✅ SAMPLE BOOKING (TESTING)
@booking_bp.route("/create-sample")
@login_required
def create_sample_booking():
    service = Service.query.first()

    if not service:
        return "No services found!"

    booking = Booking(
        customer_id=current_user.id,
        service_id=service.id,
        status="pending"
    )

    db.session.add(booking)
    db.session.commit()

    return "Sample booking created!"