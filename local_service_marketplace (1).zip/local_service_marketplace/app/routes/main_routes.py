from flask import Blueprint, render_template, redirect, url_for
from flask_login import current_user

# Create Blueprint
main_bp = Blueprint("main", __name__)


# ✅ Landing Page (Root URL)
@main_bp.route("/")
def home():
    # If user is logged in → go to dashboard
    if current_user.is_authenticated:
        return redirect(url_for("user.dashboard"))  # adjust if your dashboard route name is different

    # If not logged in → show landing page
    return render_template("landing.html")